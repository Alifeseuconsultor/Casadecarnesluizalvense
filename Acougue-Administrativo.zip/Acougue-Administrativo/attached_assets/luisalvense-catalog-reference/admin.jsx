// Admin layer — overrides, image upload, edit drawer.
// Stores all edits in localStorage so the same browser keeps changes;
// admin can export/import JSON for backups and to deploy to other devices.

const { createContext, useContext, useState, useEffect, useRef, useMemo, useCallback } = React;

const STORAGE_KEY = "lv_admin_overrides_v1";
const ADMIN_PIN_KEY = "lv_admin_pin";
const ADMIN_PIN_DEFAULT = "1290"; // troque para um PIN real em produção

/* ───────── Overrides loader ───────── */
function loadOverrides() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : { cuts: {}, meta: {}, images: {} };
  } catch (e) {
    return { cuts: {}, meta: {}, images: {} };
  }
}

function saveOverrides(o) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(o)); } catch (e) {}
}

/* ───────── Context ────────────────── */
const AdminCtx = createContext(null);

function AdminProvider({ children }) {
  const [overrides, setOverrides] = useState(loadOverrides);
  const [adminMode, setAdminMode] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [authed, setAuthed] = useState(false);

  // Persist
  useEffect(() => { saveOverrides(overrides); }, [overrides]);

  const updateCut = useCallback((id, patch) => {
    setOverrides(prev => ({
      ...prev,
      cuts: { ...prev.cuts, [id]: { ...(prev.cuts[id] || {}), ...patch } }
    }));
  }, []);

  const setImage = useCallback((id, dataUrl) => {
    setOverrides(prev => ({
      ...prev,
      images: { ...prev.images, [id]: dataUrl }
    }));
  }, []);

  const removeImage = useCallback((id) => {
    setOverrides(prev => {
      const next = { ...prev.images };
      delete next[id];
      return { ...prev, images: next };
    });
  }, []);

  const updateMeta = useCallback((key, patch) => {
    setOverrides(prev => ({
      ...prev,
      meta: { ...prev.meta, [key]: { ...(prev.meta[key] || {}), ...patch } }
    }));
  }, []);

  const resetAll = useCallback(() => {
    if (!confirm("Apagar TODAS as alterações e voltar ao catálogo original?")) return;
    setOverrides({ cuts: {}, meta: {}, images: {} });
  }, []);

  const exportJSON = useCallback(() => {
    const data = JSON.stringify(overrides, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `luisalvense-catalogo-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [overrides]);

  const importJSON = useCallback((file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target.result);
        if (!confirm("Substituir todas as alterações atuais pelas do arquivo?")) return;
        setOverrides({
          cuts: data.cuts || {},
          meta: data.meta || {},
          images: data.images || {},
        });
      } catch (err) {
        alert("Arquivo inválido. Selecione um JSON exportado pelo catálogo.");
      }
    };
    reader.readAsText(file);
  }, []);

  // Resolved cut: merges base + overrides + image
  const resolveCut = useCallback((cut) => {
    const o = overrides.cuts[cut.id] || {};
    const img = overrides.images[cut.id];
    return { ...cut, ...o, _image: img };
  }, [overrides]);

  const editCount = Object.keys(overrides.cuts).length + Object.keys(overrides.images).length;

  const value = {
    overrides, adminMode, setAdminMode,
    editingId, setEditingId,
    authed, setAuthed,
    updateCut, setImage, removeImage, updateMeta,
    resetAll, exportJSON, importJSON, resolveCut, editCount,
  };

  return <AdminCtx.Provider value={value}>{children}</AdminCtx.Provider>;
}

function useAdmin() { return useContext(AdminCtx); }

/* ───────── Admin Bar ───────────────── */
function AdminBar() {
  const a = useAdmin();
  const fileRef = useRef(null);

  if (!a.adminMode) {
    return (
      <button className="admin-toggle" onClick={() => {
        const stored = localStorage.getItem(ADMIN_PIN_KEY) || ADMIN_PIN_DEFAULT;
        const pin = prompt("PIN de administrador:");
        if (pin == null) return;
        if (pin === stored) {
          a.setAdminMode(true);
          a.setAuthed(true);
        } else {
          alert("PIN incorreto.");
        }
      }} aria-label="Modo administrador">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"
             strokeLinecap="round" strokeLinejoin="round">
          <rect x="4" y="11" width="16" height="9" rx="1" />
          <path d="M8 11V7a4 4 0 0 1 8 0v4" />
        </svg>
      </button>
    );
  }

  return (
    <div className="admin-bar">
      <div className="admin-bar-inner">
        <div className="admin-brand">
          <span className="admin-dot" />
          <span>MODO ADMIN</span>
          <span className="admin-mute"> · {a.editCount} {a.editCount === 1 ? "edição" : "edições"}</span>
        </div>
        <div className="admin-actions">
          <a className="admin-btn" href="print.html" target="_blank" rel="noreferrer" title="Abrir versão imprimível para gerar PDF" style={{textDecoration:"none"}}>
            ⊞ Gerar PDF
          </a>
          <button className="admin-btn" onClick={a.exportJSON} title="Baixa um arquivo JSON com todas as alterações">
            ↓ Exportar
          </button>
          <button className="admin-btn" onClick={() => fileRef.current?.click()} title="Carrega um JSON exportado">
            ↑ Importar
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            style={{ display: "none" }}
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) a.importJSON(f);
              e.target.value = "";
            }}
          />
          <button className="admin-btn admin-btn-danger" onClick={a.resetAll}>
            Resetar
          </button>
          <button className="admin-btn admin-btn-primary" onClick={() => a.setAdminMode(false)}>
            Sair
          </button>
        </div>
      </div>
      <div className="admin-hint">
        Clique em qualquer corte para editar. Arraste imagens para a foto. Tudo salva automaticamente neste navegador.
      </div>
    </div>
  );
}

/* ───────── Edit Drawer ─────────────── */
function EditDrawer() {
  const a = useAdmin();
  if (!a.editingId) return null;

  // find original cut
  const all = window.LV_DATA.CATALOG.flatMap(s => s.cuts);
  const base = all.find(c => c.id === a.editingId);
  if (!base) return null;
  const cut = a.resolveCut(base);

  return (
    <>
      <div className="drawer-backdrop" onClick={() => a.setEditingId(null)} />
      <aside className="drawer">
        <DrawerForm cut={cut} base={base} />
      </aside>
    </>
  );
}

function DrawerForm({ cut, base }) {
  const a = useAdmin();
  const dropRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);

  const handleFile = (file) => {
    if (!file || !file.type.startsWith("image/")) return;
    if (file.size > 4 * 1024 * 1024) {
      if (!confirm("Imagem maior que 4MB. Continuar mesmo assim? Recomendamos comprimir antes.")) return;
    }
    const reader = new FileReader();
    reader.onload = (e) => a.setImage(cut.id, e.target.result);
    reader.readAsDataURL(file);
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    handleFile(e.dataTransfer.files?.[0]);
  };

  const update = (patch) => a.updateCut(cut.id, patch);
  const reset = (field) => {
    const o = a.overrides.cuts[cut.id] || {};
    const next = { ...o };
    delete next[field];
    a.updateCut(cut.id, { [field]: undefined });
    // If we wrote undefined, prune
    if (Object.values(next).every(v => v === undefined)) {
      // already in state — nothing else
    }
  };

  return (
    <div className="drawer-form">
      <header className="drawer-head">
        <div>
          <div className="drawer-eyebrow">Editando</div>
          <h2 className="drawer-title">{cut.name}</h2>
        </div>
        <button className="drawer-close" onClick={() => a.setEditingId(null)} aria-label="Fechar">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M6 6l12 12M18 6L6 18" />
          </svg>
        </button>
      </header>

      <section className="drawer-section">
        <label className="drawer-label">Foto do corte</label>
        <div
          ref={dropRef}
          className={`drawer-photo ${dragOver ? "drag" : ""}`}
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={onDrop}
          onClick={() => dropRef.current.querySelector("input").click()}
        >
          {cut._image ? (
            <>
              <img src={cut._image} alt={cut.name} />
              <button
                className="drawer-photo-remove"
                onClick={(e) => { e.stopPropagation(); a.removeImage(cut.id); }}
              >
                Remover foto
              </button>
            </>
          ) : (
            <div className="drawer-photo-empty">
              <strong>Arraste uma foto aqui</strong>
              <span>ou clique para selecionar · PNG/JPG</span>
            </div>
          )}
          <input
            type="file"
            accept="image/*"
            style={{ display: "none" }}
            onChange={(e) => handleFile(e.target.files?.[0])}
          />
        </div>
      </section>

      <section className="drawer-section">
        <label className="drawer-label">Nome</label>
        <input
          className="drawer-input"
          value={cut.name}
          onChange={(e) => update({ name: e.target.value })}
        />
        <ResetBtn show={cut.name !== base.name} onClick={() => update({ name: base.name })} />
      </section>

      <div className="drawer-row">
        <section className="drawer-section">
          <label className="drawer-label">Preço</label>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--ink-mute)" }}>R$</span>
            <input
              className="drawer-input"
              type="number"
              step="0.01"
              value={cut.price ?? ""}
              placeholder="—"
              onChange={(e) => update({ price: e.target.value === "" ? null : parseFloat(e.target.value) })}
            />
          </div>
          <ResetBtn show={cut.price !== base.price} onClick={() => update({ price: base.price })} />
        </section>
        <section className="drawer-section">
          <label className="drawer-label">Unidade</label>
          <select
            className="drawer-input"
            value={cut.unit || "kg"}
            onChange={(e) => update({ unit: e.target.value })}
          >
            <option value="kg">kg</option>
            <option value="un">unidade</option>
            <option value="100g">100g</option>
            <option value="kit">kit</option>
          </select>
        </section>
      </div>

      <section className="drawer-section">
        <label className="drawer-label">Frase de chamada (itálico no card)</label>
        <input
          className="drawer-input"
          value={cut.tagline || ""}
          placeholder="Ex.: A rainha do churrasco brasileiro."
          onChange={(e) => update({ tagline: e.target.value })}
        />
      </section>

      <section className="drawer-section">
        <label className="drawer-label">Descrição (texto longo)</label>
        <textarea
          className="drawer-input drawer-textarea"
          rows="3"
          value={cut.desc || ""}
          placeholder="Descrição detalhada que aparece ao expandir o card."
          onChange={(e) => update({ desc: e.target.value })}
        />
      </section>

      <div className="drawer-row">
        <section className="drawer-section">
          <label className="drawer-label">Marmoreio (1–5)</label>
          <input
            className="drawer-input"
            type="number" min="0" max="5" step="1"
            value={cut.marmoreio ?? ""}
            onChange={(e) => update({ marmoreio: e.target.value === "" ? null : parseInt(e.target.value) })}
          />
        </section>
        <section className="drawer-section">
          <label className="drawer-label">Categoria</label>
          <select
            className="drawer-input"
            value={cut.tier || "classic"}
            onChange={(e) => update({ tier: e.target.value })}
          >
            <option value="signature">Assinatura</option>
            <option value="premium">Premium</option>
            <option value="classic">Clássico</option>
            <option value="daily">Do dia a dia</option>
          </select>
        </section>
      </div>

      <section className="drawer-section">
        <label className="drawer-label">Modos de preparo</label>
        <div className="chip-grid">
          {Object.entries(window.LV_DATA.USE).map(([k, v]) => {
            const active = (cut.uses || []).includes(k);
            return (
              <button
                key={k}
                className={`chip ${active ? "active" : ""}`}
                onClick={() => {
                  const cur = cut.uses || [];
                  const next = active ? cur.filter(x => x !== k) : [...cur, k];
                  update({ uses: next });
                }}
              >
                {v.label}
              </button>
            );
          })}
        </div>
      </section>

      <section className="drawer-section">
        <label className="drawer-label">Selos (separados por vírgula)</label>
        <input
          className="drawer-input"
          value={(cut.badges || []).join(", ")}
          placeholder="Ex.: Maturado 21d, Mais pedido"
          onChange={(e) => update({
            badges: e.target.value.split(",").map(s => s.trim()).filter(Boolean)
          })}
        />
      </section>

      <footer className="drawer-foot">
        <button
          className="admin-btn admin-btn-danger"
          onClick={() => {
            if (confirm("Voltar este corte ao original?")) {
              const o = { ...a.overrides };
              delete o.cuts[cut.id];
              delete o.images[cut.id];
              localStorage.setItem(STORAGE_KEY, JSON.stringify(o));
              location.reload();
            }
          }}
        >
          Resetar este corte
        </button>
        <button className="admin-btn admin-btn-primary" onClick={() => a.setEditingId(null)}>
          Concluído
        </button>
      </footer>
    </div>
  );
}

function ResetBtn({ show, onClick }) {
  if (!show) return null;
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        background: "transparent", border: 0,
        fontFamily: "var(--mono)", fontSize: 10,
        letterSpacing: "0.2em", textTransform: "uppercase",
        color: "var(--ink-mute)", cursor: "pointer", padding: "4px 0",
        marginTop: 4, alignSelf: "flex-start",
      }}
    >
      ↺ original
    </button>
  );
}

Object.assign(window, { AdminProvider, useAdmin, AdminBar, EditDrawer, AdminCtx });
