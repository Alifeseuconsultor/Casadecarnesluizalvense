// Casa de Carnes Luisalvense — main app

const { useState, useEffect, useMemo, useRef } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "palette": "brasa",
  "showMarbling": true,
  "showBadges": true,
  "showCalculator": true,
  "showCombos": true,
  "density": "comfortable",
  "phone": "+5500000000000",
  "store": "Av. das Brasas, 1290 · Centro"
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [cart, setCart] = useState([]);
  const [activeSection, setActiveSection] = useState("especiais");

  useEffect(() => {
    document.documentElement.setAttribute("data-palette", t.palette || "brasa");
  }, [t.palette]);

  // Track active section for top nav
  useEffect(() => {
    const sections = document.querySelectorAll("[data-section]");
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) setActiveSection(e.target.dataset.section);
      });
    }, { rootMargin: "-30% 0px -60% 0px" });
    sections.forEach(s => obs.observe(s));
    return () => obs.disconnect();
  }, []);

  const handleAdd = (cut) => {
    setCart(prev => {
      const found = prev.find(p => p.id === cut.id);
      if (found) return prev.map(p => p.id === cut.id ? { ...p, qty: p.qty + 1 } : p);
      return [...prev, { ...cut, qty: 1 }];
    });
    // gentle visual feedback could go here
  };

  const sections = window.LV_DATA.CATALOG;
  const meta = window.LV_DATA.SECTION_META;
  const allCuts = sections.flatMap(s => s.cuts);

  // Total prices average for hero stat
  const cuts100 = allCuts.length;
  const cutsPremium = allCuts.filter(c => c.tier === "signature" || c.tier === "premium").length;

  const phoneDigits = (t.phone || "").replace(/\D/g, "");
  const phoneValid = phoneDigits.length >= 12 && !/^5500/.test(phoneDigits);
  const orderText = useMemo(() => {
    const lines = cart.length
      ? cart.map(c => `· ${c.qty}x ${c.name}${c.price ? ` (R$ ${c.price.toFixed(2).replace('.', ',')}/${c.unit})` : ""}`).join("\n")
      : "Olá! Gostaria de fazer um pedido.";
    return cart.length
      ? `Olá Luiz Alvense! Gostaria de pedir:\n\n${lines}\n\nObrigado.`
      : lines;
  }, [cart]);
  const waLink = phoneValid
    ? `https://wa.me/${phoneDigits}?text=${encodeURIComponent(orderText)}`
    : "#configurar-whatsapp";

  const handleWa = (e) => {
    if (!phoneValid) {
      e.preventDefault();
      const copy = window.prompt(
        "Para enviar pelo WhatsApp, configure o número da loja em Tweaks → Loja.\n\nEnquanto isso, copie a mensagem do pedido abaixo:",
        orderText
      );
    }
  };

  return (
    <>
      <TopBar activeSection={activeSection} cart={cart} waLink={waLink} onWa={handleWa} />
      <Hero stats={{ cuts: cuts100, premium: cutsPremium }} />

      {/* CORTES ESPECIAIS — vitrine cinematográfica */}
      <SignatureSection
        section={sections.find(s => s.section === "especiais")}
        meta={meta["especiais"]}
        showMarbling={t.showMarbling}
        showBadges={t.showBadges}
        onAdd={handleAdd}
      />

      {/* BOVINOS S/ OSSO */}
      <CutsSection
        section={sections.find(s => s.section === "bovino-sem-osso")}
        meta={meta["bovino-sem-osso"]}
        showMarbling={t.showMarbling}
        showBadges={t.showBadges}
        onAdd={handleAdd}
      />

      {/* CALCULADORA */}
      {t.showCalculator && <Calculator cuts={allCuts} />}

      {/* BOVINOS C/ OSSO */}
      <CutsSection
        section={sections.find(s => s.section === "bovino-com-osso")}
        meta={meta["bovino-com-osso"]}
        showMarbling={t.showMarbling}
        showBadges={t.showBadges}
        onAdd={handleAdd}
      />

      {/* CORTES INTEIROS */}
      <CutsSection
        section={sections.find(s => s.section === "inteiros")}
        meta={meta["inteiros"]}
        showMarbling={false}
        showBadges={t.showBadges}
        onAdd={handleAdd}
      />

      {/* COMBOS */}
      {t.showCombos && <CombosSection onAdd={handleAdd} />}

      {/* SUÍNA */}
      <CutsSection
        section={sections.find(s => s.section === "suina")}
        meta={meta["suina"]}
        showMarbling={t.showMarbling}
        showBadges={t.showBadges}
        onAdd={handleAdd}
      />

      {/* OVINA — small signature treatment */}
      <SignatureSection
        section={sections.find(s => s.section === "ovina")}
        meta={meta["ovina"]}
        layout="ovina"
        showMarbling={t.showMarbling}
        showBadges={t.showBadges}
        onAdd={handleAdd}
      />

      {/* AVES */}
      <CutsSection
        section={sections.find(s => s.section === "aves")}
        meta={meta["aves"]}
        showMarbling={false}
        showBadges={t.showBadges}
        onAdd={handleAdd}
      />

      {/* EMBUTIDOS */}
      <CutsSection
        section={sections.find(s => s.section === "embutidos")}
        meta={meta["embutidos"]}
        showMarbling={false}
        showBadges={t.showBadges}
        onAdd={handleAdd}
      />

      {/* MIÚDOS BOVINOS */}
      <CutsSection
        section={sections.find(s => s.section === "miudos-bovinos")}
        meta={meta["miudos-bovinos"]}
        showMarbling={false}
        showBadges={t.showBadges}
        onAdd={handleAdd}
      />

      {/* MIÚDOS SUÍNOS */}
      <CutsSection
        section={sections.find(s => s.section === "miudos-suinos")}
        meta={meta["miudos-suinos"]}
        showMarbling={false}
        showBadges={t.showBadges}
        onAdd={handleAdd}
      />

      {/* DIVERSOS */}
      <CutsSection
        section={sections.find(s => s.section === "diversos")}
        meta={meta["diversos"]}
        showMarbling={false}
        showBadges={t.showBadges}
        onAdd={handleAdd}
      />

      <CTABand cart={cart} waLink={waLink} onWa={handleWa} />
      <Footer store={t.store} phone={t.phone} />

      <a className="wa-float" href={waLink} target="_blank" rel="noreferrer" onClick={handleWa} aria-label="Pedir pelo WhatsApp">
        <Icon name="whatsapp" />
      </a>

      <TweakControls t={t} setTweak={setTweak} />
    </>
  );
}

/* ───────── TopBar ────────────────────────── */
function TopBar({ activeSection, cart, waLink, onWa }) {
  const meta = window.LV_DATA.SECTION_META;
  const navItems = [
    { id: "especiais", label: "Especiais" },
    { id: "bovino-sem-osso", label: "Bovinos" },
    { id: "inteiros", label: "Inteiros" },
    { id: "suina", label: "Suína" },
    { id: "ovina", label: "Ovina" },
    { id: "aves", label: "Aves" },
    { id: "embutidos", label: "Embutidos" },
    { id: "miudos-bovinos", label: "Miúdos" },
    { id: "diversos", label: "Diversos" },
  ];
  const cartCount = cart.reduce((sum, c) => sum + c.qty, 0);
  return (
    <header className="topbar">
      <div className="topbar-inner">
        <a className="brand" href="#top">
          <BullMark />
          <div>
            <div className="brand-name">LUISALVENSE</div>
            <div className="brand-tag">Casa de Carnes · desde 2008</div>
          </div>
        </a>
        <nav className="topnav">
          {navItems.map(n => (
            <a key={n.id} href={`#${n.id}`} className={activeSection === n.id ? "active" : ""}>
              {n.label}
            </a>
          ))}
        </nav>
        <a className="topnav-cta" href={waLink} target="_blank" rel="noreferrer" onClick={onWa}>
          <Icon name="whatsapp" style={{ width: 14, height: 14 }} />
          {cartCount > 0 ? `Pedir ${cartCount}` : "Pedir agora"}
        </a>
      </div>
    </header>
  );
}

/* ───────── Hero ──────────────────────────── */
function Hero({ stats }) {
  const today = new Date();
  const months = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"];
  const dateStr = `${String(today.getDate()).padStart(2,"0")} ${months[today.getMonth()]} ${today.getFullYear()}`;

  return (
    <section className="hero" id="top">
      <div className="wrap hero-inner">
        <div className="hero-meta">
          <div className="hero-meta-line">
            <span>Edição N.º 04</span>
            <span className="dot" />
            <span>Vol. III</span>
            <span className="dot" />
            <span>{dateStr}</span>
          </div>
          <div className="hero-meta-line">
            <span>Catálogo Premium</span>
            <span className="dot" />
            <span>Tabela vigente</span>
          </div>
        </div>

        <h1 className="hero-title">
          <span className="light">Casa de Carnes</span>
          O sabor <span className="accent">do corte</span><br />
          certo.
        </h1>

        <div className="hero-foot">
          <p className="hero-lede">
            Selecionamos a fundo, maturamos com paciência e cortamos sob medida.
            Um catálogo dos cortes que valem cada minuto na brasa, na panela e na mesa.
          </p>
          <div className="hero-stat">
            <div className="hero-stat-num">{stats.cuts}+</div>
            <div className="hero-stat-lbl">Cortes catalogados</div>
          </div>
          <div className="hero-stat">
            <div className="hero-stat-num">{stats.premium}</div>
            <div className="hero-stat-lbl">Cortes premium</div>
          </div>
        </div>
      </div>
      <div className="hero-edition">
        Pedidos<br />
        WhatsApp · Retirada em loja<br />
        Ter–Sáb · 08h às 19h
      </div>
    </section>
  );
}

/* ───────── Signature Section (cortes especiais cinemato) */
function SignatureSection({ section, meta, layout, showMarbling, showBadges, onAdd }) {
  if (!section) return null;
  const cuts = section.cuts;

  // Layout patterns
  const layoutClasses = layout === "ovina"
    ? ["sig-half", "sig-half", "sig-half", "sig-half"]
    : ["sig-hero", "sig-tall", "sig-third", "sig-third", "sig-third"];

  return (
    <section className="section" id={meta.id} data-section={meta.id}>
      <div className="wrap">
        <SectionHead no={meta.no} label={meta.label} kicker={meta.kicker} count={cuts.length} />
        <div className="signature-grid">
          {cuts.map((c, i) => (
            <SigCard
              key={c.id}
              cut={c}
              layout={layoutClasses[i] || "sig-third"}
              showMarbling={showMarbling}
              showBadges={showBadges}
              onAdd={onAdd}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

/* ───────── Regular cuts grid ─────────────── */
function CutsSection({ section, meta, showMarbling, showBadges, onAdd }) {
  if (!section) return null;
  const cuts = section.cuts;
  const [expanded, setExpanded] = useState(null);

  return (
    <section className="section" id={meta.id} data-section={meta.id}>
      <div className="wrap">
        <SectionHead no={meta.no} label={meta.label} kicker={meta.kicker} count={cuts.length} />
        <div className="cuts-grid">
          {cuts.map(c => (
            <CutCard
              key={c.id}
              cut={c}
              showMarbling={showMarbling}
              showBadges={showBadges}
              onAdd={onAdd}
              expanded={expanded === c.id}
              onToggle={() => setExpanded(expanded === c.id ? null : c.id)}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

/* ───────── Combos ────────────────────────── */
function CombosSection({ onAdd }) {
  return (
    <section className="section" id="combos" data-section="combos">
      <div className="wrap">
        <SectionHead
          no="★"
          label="Kits prontos · da casa"
          kicker="Combinações curadas pelos nossos açougueiros para reuniões certeiras."
          count={window.LV_DATA.COMBOS.length}
        />
        <div className="combos">
          {window.LV_DATA.COMBOS.map(k => (
            <article key={k.id} className="combo">
              <div className="combo-tag">Kit</div>
              <div>
                <h3 className="combo-name">{k.name}</h3>
                <p className="combo-serves" style={{ marginTop: 8 }}>{k.serves}</p>
              </div>
              <ul className="combo-list">
                {k.items.map((i, idx) => <li key={idx}>{i}</li>)}
              </ul>
              <div className="combo-foot">
                <div>
                  <div className="combo-price">R$ {k.price.toFixed(2).replace('.', ',')}</div>
                  <div className="combo-save">Economize R$ {k.save}</div>
                </div>
                <button className="cut-add" onClick={() => onAdd?.({ id: k.id, name: k.name, price: k.price, unit: "kit", qty: 1 })}>
                  <Icon name="plus" />
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ───────── Calculator (simulador churrasco) */
function Calculator({ cuts }) {
  const [people, setPeople] = useState(8);
  const [profile, setProfile] = useState("classico"); // classico | premium | familia

  const profiles = {
    classico: {
      label: "Clássico",
      kicker: "Picanha, fraldinha e linguicinha. O básico bem feito.",
      grams: { adult: 400 },
      mix: [
        { id: "picanha", share: 0.40 },
        { id: "fraldinha", share: 0.30 },
        { id: "ling-caseira", share: 0.20 },
        { id: "coracao", share: 0.10 },
      ],
    },
    premium: {
      label: "Premium",
      kicker: "Tomahawk, Prime Rib e cortes maturados.",
      grams: { adult: 450 },
      mix: [
        { id: "tomahawk", share: 0.35 },
        { id: "prime-rib", share: 0.30 },
        { id: "entrecot", share: 0.20 },
        { id: "ling-costela-bovina", share: 0.15 },
      ],
    },
    familia: {
      label: "Família",
      kicker: "Costela longa, linguiça e coração para o domingo todo.",
      grams: { adult: 500 },
      mix: [
        { id: "costela-ripa", share: 0.45 },
        { id: "fraldinha", share: 0.20 },
        { id: "ling-boa-brasa", share: 0.25 },
        { id: "coracao", share: 0.10 },
      ],
    },
  };

  const p = profiles[profile];
  const totalGrams = people * p.grams.adult;
  const items = useMemo(() => {
    return p.mix.map(m => {
      const cut = cuts.find(c => c.id === m.id);
      const grams = totalGrams * m.share;
      const kg = grams / 1000;
      const cost = (cut?.price || 0) * kg;
      return { ...m, cut, kg, cost };
    });
  }, [profile, people, cuts]);
  const total = items.reduce((s, i) => s + i.cost, 0);

  return (
    <section className="section" id="calculadora" data-section="calculadora">
      <div className="wrap">
        <div className="calc">
          <div>
            <div className="section-no" style={{ marginBottom: 16 }}>SIMULADOR</div>
            <h2 className="calc-title">Quanto pedir <em>para o seu churrasco</em>?</h2>
            <p className="calc-kicker">
              Ajuste o número de convidados e o estilo. Calculamos as quantidades certas e o custo estimado em segundos.
            </p>

            <div className="calc-controls">
              <div className="calc-row">
                <div className="calc-row-head">
                  <span className="calc-label">Convidados</span>
                  <span className="calc-val">{people}<span className="small">pessoas</span></span>
                </div>
                <input
                  className="calc-slider" type="range"
                  min="2" max="40" step="1"
                  value={people}
                  onChange={(e) => setPeople(+e.target.value)}
                />
              </div>

              <div className="calc-row">
                <div className="calc-row-head">
                  <span className="calc-label">Estilo</span>
                  <span className="calc-val" style={{ fontSize: 18, color: "var(--ink-soft)" }}>{p.kicker}</span>
                </div>
                <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                  {Object.entries(profiles).map(([k, v]) => (
                    <button
                      key={k}
                      onClick={() => setProfile(k)}
                      style={{
                        flex: 1,
                        padding: "14px 16px",
                        border: `1px solid ${profile === k ? "var(--brass)" : "var(--line-strong)"}`,
                        background: profile === k ? "color-mix(in srgb, var(--brass) 18%, transparent)" : "transparent",
                        color: profile === k ? "var(--brass-glow)" : "var(--ink)",
                        fontFamily: "var(--mono)",
                        fontSize: 11,
                        letterSpacing: "0.18em",
                        textTransform: "uppercase",
                        cursor: "pointer",
                        transition: "all .2s",
                        borderRadius: 2,
                      }}
                    >
                      {v.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="calc-output">
            <div className="calc-out-label">Sua lista sugerida</div>
            <div className="calc-out-rows">
              {items.map((i, idx) => (
                <div key={idx} className="calc-out-row">
                  <div className="calc-out-name">
                    {i.cut?.name || i.id}
                    <small>{i.kg.toFixed(2)} kg</small>
                  </div>
                  <div className="calc-out-qty">
                    R$ {i.cost.toFixed(2).replace('.', ',')}
                  </div>
                </div>
              ))}
            </div>
            <div className="calc-out-total">
              <span className="calc-out-total-label">Total estimado</span>
              <span className="calc-out-total-val">R$ {total.toFixed(2).replace('.', ',')}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ───────── CTA Band ──────────────────────── */
function CTABand({ cart, waLink, onWa }) {
  return (
    <section className="cta-band">
      <div className="wrap" style={{ position: "relative", zIndex: 1 }}>
        <div className="cta-eyebrow">Reserva e retirada</div>
        <h2 className="cta-title">Reserve seu corte. <em>Retire fresco.</em></h2>
        <p className="cta-sub">
          Reservas pelo WhatsApp são separadas e embaladas a vácuo. Chegue, retire, vá direto para o fogo.
        </p>
        <div className="cta-actions">
          <a className="btn btn-primary" href={waLink} target="_blank" rel="noreferrer" onClick={onWa}>
            <Icon name="whatsapp" /> Pedir pelo WhatsApp
            {cart.length > 0 && <span style={{ marginLeft: 8, opacity: 0.7 }}>· {cart.length} {cart.length === 1 ? "item" : "itens"}</span>}
          </a>
          <a className="btn btn-ghost" href="#calculadora">
            Simular meu churrasco <Icon name="arrow" />
          </a>
        </div>
      </div>
    </section>
  );
}

/* ───────── Footer ────────────────────────── */
function Footer({ store, phone }) {
  return (
    <footer className="footer">
      <div className="wrap">
        <div className="footer-grid">
          <div>
            <a className="brand" href="#top" style={{ marginBottom: 20, display: "inline-flex" }}>
              <BullMark />
              <div>
                <div className="brand-name">LUISALVENSE</div>
                <div className="brand-tag">Casa de Carnes</div>
              </div>
            </a>
            <p style={{ marginTop: 16, maxWidth: "36ch" }}>
              Carnes selecionadas, maturadas e cortadas com cuidado artesanal. Atendimento balcão e WhatsApp para pedidos antecipados.
            </p>
          </div>
          <div>
            <h4>Visite</h4>
            <p>{store}</p>
            <p style={{ marginTop: 12 }}>Ter–Sáb · 08h–19h<br />Dom · 08h–13h</p>
          </div>
          <div>
            <h4>Pedidos</h4>
            <ul>
              <li><a href={`https://wa.me/${(phone || "").replace(/\D/g, "")}`} target="_blank" rel="noreferrer">WhatsApp</a></li>
              <li><a href="#calculadora">Simulador de churrasco</a></li>
              <li><a href="#combos">Kits prontos</a></li>
            </ul>
          </div>
          <div>
            <h4>Catálogo</h4>
            <ul>
              <li><a href="#especiais">Cortes especiais</a></li>
              <li><a href="#bovino-sem-osso">Bovinos</a></li>
              <li><a href="#suina">Suína · Ovina</a></li>
              <li><a href="#embutidos">Embutidos da casa</a></li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2026 Luisalvense Casa de Carnes</span>
          <span>Catálogo edição N.º 04 · Vol. III</span>
          <span>Preços por kg sujeitos a variação</span>
        </div>
      </div>
    </footer>
  );
}

/* ───────── Tweaks Panel ─────────────────── */
function TweakControls({ t, setTweak }) {
  return (
    <TweaksPanel title="Tweaks · Catálogo">
      <TweakSection label="Identidade visual">
        <TweakRadio
          label="Paleta"
          value={t.palette}
          onChange={(v) => setTweak('palette', v)}
          options={[
            { value: "brasa", label: "Brasa" },
            { value: "linho", label: "Linho" },
            { value: "mono", label: "Mono" },
          ]}
        />
      </TweakSection>

      <TweakSection label="Persuasão">
        <TweakToggle label="Indicador de marmoreio" value={t.showMarbling} onChange={(v) => setTweak('showMarbling', v)} />
        <TweakToggle label="Selos & badges" value={t.showBadges} onChange={(v) => setTweak('showBadges', v)} />
        <TweakToggle label="Calculadora de churrasco" value={t.showCalculator} onChange={(v) => setTweak('showCalculator', v)} />
        <TweakToggle label="Kits prontos" value={t.showCombos} onChange={(v) => setTweak('showCombos', v)} />
      </TweakSection>

      <TweakSection label="Loja">
        <TweakText label="Endereço" value={t.store} onChange={(v) => setTweak('store', v)} />
        <TweakText label="WhatsApp" value={t.phone} onChange={(v) => setTweak('phone', v)} />
      </TweakSection>
    </TweaksPanel>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <AdminProvider>
    <AdminLayer>
      <App />
    </AdminLayer>
  </AdminProvider>
);

function AdminLayer({ children }) {
  const a = useAdmin();
  useEffect(() => {
    document.body.classList.toggle("admin-active", a.adminMode);
  }, [a.adminMode]);
  return (
    <>
      <AdminBar />
      {children}
      <EditDrawer />
    </>
  );
}
