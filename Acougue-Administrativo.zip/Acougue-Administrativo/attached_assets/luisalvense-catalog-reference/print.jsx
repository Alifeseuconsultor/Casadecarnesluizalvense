// Print catalog renderer — A4, multi-page, otimizado para PDF/WhatsApp

const { useMemo } = React;

const STORAGE_KEY = "lv_admin_overrides_v1";
function loadOverrides() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || { cuts: {}, images: {} }; }
  catch (e) { return { cuts: {}, images: {} }; }
}

const SECTION_ORDER = [
  "especiais", "bovino-sem-osso", "bovino-com-osso",
  "inteiros", "suina", "ovina", "aves", "embutidos",
  "miudos-bovinos", "miudos-suinos", "diversos",
];

function PrintApp() {
  const overrides = loadOverrides();
  const meta = window.LV_DATA.SECTION_META;
  const sections = SECTION_ORDER
    .map(id => window.LV_DATA.CATALOG.find(s => s.section === id))
    .filter(Boolean);

  // Resolve cuts with overrides applied
  const resolved = sections.map(s => ({
    ...s,
    meta: meta[s.section],
    cuts: s.cuts.map(c => ({
      ...c,
      ...(overrides.cuts[c.id] || {}),
      _image: overrides.images[c.id],
    })),
  }));

  // Compute pagination — track section start pages for index
  let pageNo = 3; // cover=1, index=2, then sections start
  const sectionPages = resolved.map(s => {
    const start = pageNo;
    // featured (signature/premium) first 3-4 cuts get a featured page
    const isSignatureSection = s.section === "especiais" || s.section === "ovina";
    const featuredCount = isSignatureSection ? Math.min(3, s.cuts.length) : 0;
    const remaining = s.cuts.length - featuredCount;
    // 6 cuts per page (2x3 grid)
    const remainingPages = Math.ceil(remaining / 6) || (s.cuts.length === 0 ? 0 : 1);
    const featuredPages = featuredCount > 0 ? 1 : 0;
    const total = featuredPages + remainingPages;
    pageNo += total;
    return { start, total };
  });
  const closingPage = pageNo;

  const today = new Date();
  const months = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"];
  const dateStr = `${String(today.getDate()).padStart(2,"0")} ${months[today.getMonth()]} ${today.getFullYear()}`;

  const totalCuts = resolved.reduce((n, s) => n + s.cuts.length, 0);
  const premiumCuts = resolved.flatMap(s => s.cuts).filter(c => c.tier === "signature" || c.tier === "premium").length;

  return (
    <>
      <Toolbar />
      <Cover dateStr={dateStr} totalCuts={totalCuts} premiumCuts={premiumCuts} />
      <IndexPage sections={resolved} sectionPages={sectionPages} />
      {resolved.map((s, i) => (
        <SectionPages key={s.section} section={s} no={s.meta.no} startPage={sectionPages[i].start} />
      ))}
      <Closing pageNo={closingPage} />
    </>
  );
}

function Toolbar() {
  return (
    <div className="toolbar">
      <span>CATÁLOGO IMPRIMÍVEL</span>
      <button onClick={() => window.print()}>↓ Salvar PDF</button>
      <button className="ghost" onClick={() => location.href = "index.html"}>Voltar</button>
    </div>
  );
}

function BullSVG() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 7c-.5-2 1-3 2-3 1.5 0 2 1 2 2M19 7c.5-2-1-3-2-3-1.5 0-2 1-2 2" />
      <path d="M7 7c0 4 2 8 5 8s5-4 5-8" />
      <circle cx="9.5" cy="11" r="0.6" fill="currentColor" />
      <circle cx="14.5" cy="11" r="0.6" fill="currentColor" />
      <path d="M10 14.5c.6.4 1.4.5 2 .5s1.4-.1 2-.5" />
    </svg>
  );
}

/* ───── Cover ───── */
function Cover({ dateStr, totalCuts, premiumCuts }) {
  return (
    <article className="page cover">
      <div className="cover-top">
        <span>Edição N.º 04 · Vol. III</span>
        <span>{dateStr}</span>
      </div>
      <div className="cover-mark"><BullSVG /></div>
      <div className="cover-brand">LUIZ ALVENSE</div>
      <div className="cover-brand-tag">Casa de Carnes · desde 2008</div>

      <h1 className="cover-title">
        <span className="light">Casa de Carnes</span>
        O sabor <span className="accent">do corte</span> certo.
      </h1>

      <p className="cover-lede">
        Selecionamos a fundo, maturamos com paciência e cortamos sob medida.
        Um catálogo dos cortes que valem cada minuto na brasa, na panela e na mesa.
      </p>

      <div className="cover-bottom">
        <div>
          <div className="cover-stat-num">{totalCuts}+</div>
          <div className="cover-stat-lbl">Cortes catalogados</div>
        </div>
        <div>
          <div className="cover-stat-num">{premiumCuts}</div>
          <div className="cover-stat-lbl">Cortes premium</div>
        </div>
        <div>
          <div className="cover-stat-num">21</div>
          <div className="cover-stat-lbl">Dias de maturação</div>
        </div>
      </div>
      <div className="cover-edition">Catálogo Premium · Tabela vigente</div>
    </article>
  );
}

/* ───── Index ───── */
function IndexPage({ sections, sectionPages }) {
  return (
    <article className="page">
      <div className="idx-head">
        <div>
          <div className="idx-eyebrow">Sumário</div>
          <h2 className="idx-title">Cortes · <em>capítulos</em></h2>
        </div>
        <div style={{ fontFamily: "var(--mono)", fontSize: "8pt", letterSpacing: "0.22em", textTransform: "uppercase", color: "var(--ink-mute)" }}>
          Página
        </div>
      </div>
      <ul className="idx-list">
        {sections.map((s, i) => {
          const labelParts = s.meta.label.split(" · ");
          return (
            <li className="idx-row" key={s.section}>
              <span className="no">{s.meta.no}</span>
              <span className="name">
                {labelParts.length === 2 ? <>{labelParts[0]} <em>{labelParts[1]}</em></> : s.meta.label}
              </span>
              <span className="count">{String(s.cuts.length).padStart(2, "0")} cortes</span>
              <span className="pg">{String(sectionPages[i].start).padStart(2, "0")}</span>
            </li>
          );
        })}
      </ul>
      <div className="idx-foot">
        <span>Luiz Alvense · Casa de Carnes</span>
        <span>02</span>
      </div>
    </article>
  );
}

/* ───── Section Pages ───── */
function SectionPages({ section, no, startPage }) {
  const isSignatureSection = section.section === "especiais" || section.section === "ovina";
  const featuredCount = isSignatureSection ? Math.min(3, section.cuts.length) : 0;
  const featured = section.cuts.slice(0, featuredCount);
  const rest = section.cuts.slice(featuredCount);

  // Chunk rest into groups of 6
  const chunks = [];
  for (let i = 0; i < rest.length; i += 6) chunks.push(rest.slice(i, i + 6));
  if (chunks.length === 0 && featured.length === 0 && section.cuts.length > 0) chunks.push([]);

  let curPage = startPage;
  const pages = [];

  if (featured.length > 0) {
    pages.push(
      <FeaturedPage
        key={`f-${section.section}`}
        section={section}
        cuts={featured}
        showHead
        pageNo={curPage}
      />
    );
    curPage++;
  }

  chunks.forEach((chunk, idx) => {
    pages.push(
      <GridPage
        key={`g-${section.section}-${idx}`}
        section={section}
        cuts={chunk}
        showHead={!featured.length && idx === 0}
        pageNo={curPage}
        cont={idx > 0 || featured.length > 0}
      />
    );
    curPage++;
  });

  return <>{pages}</>;
}

function SectionHead({ section, cont }) {
  const labelParts = section.meta.label.split(" · ");
  return (
    <div className="sec-head">
      <div className="sec-no">CAP {section.meta.no}</div>
      <div>
        <h2 className="sec-title">
          {labelParts.length === 2 ? <>{labelParts[0]} <em>{labelParts[1]}</em></> : section.meta.label}
          {cont && <span style={{ fontSize: "0.4em", color: "var(--ink-mute)", marginLeft: "4mm", fontStyle: "italic" }}>continua</span>}
        </h2>
        <p className="sec-kicker">{section.meta.kicker}</p>
      </div>
      <div className="sec-count">{String(section.cuts.length).padStart(2, "0")} cortes</div>
    </div>
  );
}

function CutPrice({ value, unit }) {
  if (value == null) return <span className="cut-price" style={{ color: "var(--ink-mute)" }}>consulte</span>;
  const r = Math.floor(value);
  const c = String(Math.round((value - r) * 100)).padStart(2, "0");
  return (
    <div>
      <span className="cut-price">
        <span className="currency">R$</span>{r},<span className="cents">{c}</span>
      </span>
      <div className="cut-price-unit">por {unit || "kg"}</div>
    </div>
  );
}

function Marb({ value }) {
  if (value == null) return null;
  return (
    <div className="cut-marb">
      {[1,2,3,4,5].map(i => <span key={i} className={`cut-marb-bar ${i <= value ? "on" : ""}`} />)}
      <span className="cut-marb-lbl">marmoreio {value}/5</span>
    </div>
  );
}

function CutPhoto({ cut }) {
  return (
    <div className="cut-photo">
      {cut._image
        ? <img src={cut._image} alt={cut.name} />
        : <span className="cut-photo-empty">Foto · {cut.name}</span>}
    </div>
  );
}

function UseList({ uses }) {
  if (!uses?.length) return null;
  return (
    <div className="cut-uses">
      {uses.slice(0, 3).map(u => {
        const meta = window.LV_DATA.USE[u];
        return meta ? <span key={u}>{meta.label}</span> : null;
      })}
    </div>
  );
}

function FeaturedPage({ section, cuts, showHead, pageNo }) {
  return (
    <article className="page">
      {showHead && <SectionHead section={section} />}
      <div className="cuts-featured">
        {cuts.map(c => (
          <article className="cut" key={c.id}>
            <CutPhoto cut={c} />
            <div className="cut-body">
              <div className="cut-head">
                <h3 className="cut-name">{c.name}</h3>
                <span className={`cut-tier ${c.tier || "classic"}`}>
                  {window.LV_DATA.TIER[c.tier || "classic"]?.label}
                </span>
              </div>
              {c.tagline && <p className="cut-tag">{c.tagline}</p>}
              <Marb value={c.marmoreio} />
              <div className="cut-foot">
                <UseList uses={c.uses} />
                <CutPrice value={c.price} unit={c.unit} />
              </div>
            </div>
          </article>
        ))}
      </div>
      <PageFoot section={section} pageNo={pageNo} />
    </article>
  );
}

function GridPage({ section, cuts, showHead, pageNo, cont }) {
  return (
    <article className="page">
      {(showHead || cont) && <SectionHead section={section} cont={cont && !showHead} />}
      <div className="cuts">
        {cuts.map(c => (
          <article className="cut" key={c.id}>
            <CutPhoto cut={c} />
            <div className="cut-head">
              <h3 className="cut-name">{c.name}</h3>
              <span className={`cut-tier ${c.tier || "classic"}`}>
                {window.LV_DATA.TIER[c.tier || "classic"]?.label}
              </span>
            </div>
            {c.tagline && <p className="cut-tag">{c.tagline}</p>}
            <Marb value={c.marmoreio} />
            <div className="cut-foot">
              <UseList uses={c.uses} />
              <CutPrice value={c.price} unit={c.unit} />
            </div>
          </article>
        ))}
      </div>
      <PageFoot section={section} pageNo={pageNo} />
    </article>
  );
}

function PageFoot({ section, pageNo }) {
  return (
    <div className="page-foot">
      <span>Luiz Alvense · {section.meta.label}</span>
      <span>{String(pageNo).padStart(2, "0")}</span>
    </div>
  );
}

/* ───── Closing ───── */
function Closing({ pageNo }) {
  return (
    <article className="page">
      <h2 className="close-title">
        <span className="light">Reserve seu corte</span>
        Retire <span className="accent">fresco.</span>
      </h2>

      <div className="close-grid">
        <div className="close-block">
          <h4>Pedidos</h4>
          <p>WhatsApp · (00) 00000-0000<br />Reservas embaladas a vácuo, prontas para retirada.</p>
        </div>
        <div className="close-block">
          <h4>Visite</h4>
          <p>Av. das Brasas, 1290 · Centro<br />Ter–Sáb · 08h–19h<br />Dom · 08h–13h</p>
        </div>
        <div className="close-block">
          <h4>Sob encomenda</h4>
          <ul>
            <li>· Cortes especiais maturados</li>
            <li>· Costela inteira para fogo de chão</li>
            <li>· Embutidos artesanais em volume</li>
          </ul>
        </div>
        <div className="close-block">
          <h4>Tabela vigente</h4>
          <p>Preços por kg, sujeitos a variação semanal de mercado. Catálogo Edição N.º 04 · Vol. III.</p>
        </div>
      </div>

      <div className="close-wa">
        <div className="close-wa-bubble">Peça pelo WhatsApp</div>
      </div>

      <div className="page-foot">
        <span>Luiz Alvense · Casa de Carnes</span>
        <span>{String(pageNo).padStart(2, "0")}</span>
      </div>
    </article>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<PrintApp />);
