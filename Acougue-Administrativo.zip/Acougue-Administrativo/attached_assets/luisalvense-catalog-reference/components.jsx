// Components for Luisalvense catalog

const { useState, useEffect, useMemo, useRef } = React;

/* ───────── Icons ─────────────────────────── */
function Icon({ name, ...props }) {
  const paths = {
    flame: <path d="M12 2c1 5 4 6 4 10a4 4 0 0 1-8 0c0-1 .4-1.8 1-2.5C8 8 8 7 8 5c2 1 3 2 4-3z" />,
    pot: <><path d="M3 9h18M5 9v8a3 3 0 0 0 3 3h8a3 3 0 0 0 3-3V9M9 6V4M15 6V4" /></>,
    oven: <><rect x="3" y="4" width="18" height="16" rx="1" /><path d="M3 10h18M7 7h10M7 14h10v3H7z" /></>,
    grill: <><rect x="3" y="4" width="18" height="11" rx="2" /><path d="M3 8h18M3 12h18M7 15v5M17 15v5" /></>,
    broth: <><path d="M4 11h16M5 11l1 8a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2l1-8M9 8c0-1 1-1.5 1-3M13 8c0-1 1-1.5 1-3" /></>,
    thread: <path d="M4 8c4 0 4 4 8 4s4-4 8-4M4 16c4 0 4-4 8-4s4 4 8 4" />,
    plus: <path d="M12 5v14M5 12h14" />,
    minus: <path d="M5 12h14" />,
    arrow: <path d="M5 12h14M13 5l7 7-7 7" />,
    whatsapp: <path d="M16.6 14c-.3-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1-.2.3-.7.8-.8 1-.2.1-.3.2-.5 0-.4-.2-1.4-.5-2.6-1.6-1-.9-1.6-1.9-1.8-2.3-.2-.3 0-.5.1-.7.1-.1.3-.4.4-.5.1-.1.2-.3.2-.5.1-.2 0-.4 0-.5l-.7-1.6c-.2-.4-.4-.4-.6-.4h-.5c-.2 0-.5.1-.7.3-.3.3-.9.9-.9 2.2 0 1.3 1 2.6 1.1 2.7.1.2 1.9 2.9 4.6 4 .6.3 1.1.4 1.5.5.6.2 1.2.2 1.6.1.5-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.2-1.2-.1-.1-.2-.2-.4-.3z" />,
    instagram: <><rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><circle cx="17.5" cy="6.5" r="0.5" fill="currentColor" /></>,
    map: <><path d="M21 10c0 6-9 12-9 12s-9-6-9-12a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></>,
  };
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"
         strokeLinecap="round" strokeLinejoin="round" {...props}>
      {paths[name]}
    </svg>
  );
}

/* ───────── Bull mark logo ────────────────── */
function BullMark({ size = 38 }) {
  return (
    <div className="brand-mark" style={{ width: size, height: size }}>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" style={{ color: "var(--brass-glow)" }}>
        {/* Stylized bull head */}
        <path d="M5 7c-.5-2 1-3 2-3 1.5 0 2 1 2 2M19 7c.5-2-1-3-2-3-1.5 0-2 1-2 2" />
        <path d="M7 7c0 4 2 8 5 8s5-4 5-8" />
        <circle cx="9.5" cy="11" r="0.6" fill="currentColor" />
        <circle cx="14.5" cy="11" r="0.6" fill="currentColor" />
        <path d="M10 14.5c.6.4 1.4.5 2 .5s1.4-.1 2-.5" />
      </svg>
    </div>
  );
}

/* ───────── Marbling indicator ────────────── */
function Marbling({ value = 3, label = true }) {
  return (
    <div className="marbling" title={`Marmoreio ${value}/5`}>
      {[1, 2, 3, 4, 5].map(i => (
        <span key={i} className={`marbling-bar ${i <= value ? "on" : ""}`} />
      ))}
      {label && <span className="marbling-label">marmoreio {value}/5</span>}
    </div>
  );
}

/* ───────── Use icons row ─────────────────── */
function UseIcons({ uses = [] }) {
  if (!uses.length) return null;
  return (
    <div className="cut-uses" title={uses.map(u => window.LV_DATA.USE[u]?.label).join(" · ")}>
      {uses.map(u => {
        const meta = window.LV_DATA.USE[u];
        if (!meta) return null;
        return (
          <span key={u} className="cut-use-icon" aria-label={meta.label} title={meta.label}>
            <Icon name={meta.icon} />
          </span>
        );
      })}
    </div>
  );
}

/* ───────── Price formatting ──────────────── */
function formatPrice(value) {
  if (value == null) return ["—", ""];
  const reais = Math.floor(value);
  const cents = String(Math.round((value - reais) * 100)).padStart(2, "0");
  return [reais, cents];
}

function PriceLarge({ value, unit }) {
  const [r, c] = formatPrice(value);
  if (value == null) {
    return (
      <div className="cut-price" style={{ color: "var(--ink-mute)" }}>
        consulte
      </div>
    );
  }
  return (
    <div>
      <span className="cut-price">
        <span style={{ fontFamily: "var(--mono)", fontSize: 12, letterSpacing: "0.16em", color: "var(--ink-mute)", marginRight: 4 }}>R$</span>
        {r},<span className="cents">{c}</span>
      </span>
      <div className="cut-price-unit">por {unit}</div>
    </div>
  );
}

function PriceSig({ value, unit }) {
  const [r, c] = formatPrice(value);
  if (value == null) return <span className="sig-price">consulte</span>;
  return (
    <div className="sig-price-row">
      <span className="sig-price-currency">R$</span>
      <span className="sig-price">
        {r},<span className="sig-price-cents">{c}</span>
      </span>
      <span className="sig-price-unit">/{unit}</span>
    </div>
  );
}

/* ───────── Badge ─────────────────────────── */
function Badge({ children, tone = "default" }) {
  return <span className={`badge ${tone}`}>{children}</span>;
}

function inferBadgeTone(label) {
  const l = (label || "").toLowerCase();
  if (l.includes("premium") || l.includes("edição") || l.includes("autoral") || l.includes("maturado")) return "brass";
  if (l.includes("picante") || l.includes("limit") || l.includes("pouca")) return "oxblood";
  return "default";
}

/* ───────── Signature card ────────────────── */
function SigCard({ cut: rawCut, layout = "sig-third", showMarbling = true, showBadges = true, onAdd, brand }) {
  const admin = window.useAdmin?.();
  const cut = admin ? admin.resolveCut(rawCut) : rawCut;
  const isEdited = admin && (admin.overrides.cuts[rawCut.id] || admin.overrides.images[rawCut.id]);
  const overlay = layout === "sig-hero" || layout === "sig-tall";
  const handleClick = () => {
    if (admin?.adminMode) admin.setEditingId(rawCut.id);
    else onAdd?.(cut);
  };
  return (
    <article className={`sig-card ${layout}`} onClick={handleClick}>
      <div className={`sig-image ${cut._image ? "has-photo" : ""}`} data-placeholder={`Foto · ${cut.name}`}>
        {cut._image && <img className="real-photo" src={cut._image} alt={cut.name} />}
        {overlay && <div className="sig-image-overlay" />}
      </div>
      <div className={overlay ? "sig-overlay-content" : "sig-content"}>
        {showBadges && cut.badges?.length > 0 && (
          <div className="badge-row">
            {cut.badges.map(b => <Badge key={b} tone={inferBadgeTone(b)}>{b}</Badge>)}
          </div>
        )}
        <h3 className="sig-name">
          {cut.name}
          {isEdited && <span className="edited-mark" title="Editado" />}
        </h3>
        {cut.tagline && <p className="sig-tagline">{cut.tagline}</p>}
        {showMarbling && cut.marmoreio != null && <Marbling value={cut.marmoreio} />}
        <div className="sig-foot">
          <PriceSig value={cut.price} unit={cut.unit} />
          <UseIcons uses={cut.uses} />
        </div>
      </div>
    </article>
  );
}

/* ───────── Cut card (regular) ────────────── */
function CutCard({ cut: rawCut, showMarbling = true, showBadges = true, onAdd, expanded, onToggle }) {
  const admin = window.useAdmin?.();
  const cut = admin ? admin.resolveCut(rawCut) : rawCut;
  const isEdited = admin && (admin.overrides.cuts[rawCut.id] || admin.overrides.images[rawCut.id]);
  const handleClick = () => {
    if (admin?.adminMode) admin.setEditingId(rawCut.id);
    else onToggle?.();
  };
  return (
    <article
      className={`cut-card ${expanded ? "expanded" : ""} ${cut._image ? "has-photo" : ""}`}
      onClick={handleClick}
    >
      {cut._image && (
        <div className="cut-photo has-photo">
          <img className="real-photo" src={cut._image} alt={cut.name} />
        </div>
      )}
      <div className="cut-head">
        <div style={{ flex: 1 }}>
          <h3 className="cut-name">
            {cut.name}
            {isEdited && <span className="edited-mark" title="Editado" />}
          </h3>
          {cut.tagline && <p className="cut-tagline" style={{ marginTop: 8 }}>{cut.tagline}</p>}
        </div>
        <span className={`cut-tier-dot ${cut.tier || "classic"}`} title={window.LV_DATA.TIER[cut.tier]?.label} />
      </div>

      {expanded && cut.desc && (
        <p style={{ fontFamily: "var(--sans)", fontSize: 13, color: "var(--ink-soft)", lineHeight: 1.6 }}>
          {cut.desc}
        </p>
      )}

      {showBadges && cut.badges?.length > 0 && (
        <div className="badge-row">
          {cut.badges.map(b => <Badge key={b} tone={inferBadgeTone(b)}>{b}</Badge>)}
        </div>
      )}

      <div className="cut-meta">
        {showMarbling && cut.marmoreio != null && <Marbling value={cut.marmoreio} />}
        <UseIcons uses={cut.uses} />
      </div>

      <div className="cut-foot">
        <div>
          <PriceLarge value={cut.price} unit={cut.unit} />
        </div>
        <button
          className="cut-add"
          aria-label={admin?.adminMode ? `Editar ${cut.name}` : `Pedir ${cut.name}`}
          onClick={(e) => {
            e.stopPropagation();
            if (admin?.adminMode) admin.setEditingId(rawCut.id);
            else onAdd?.(cut);
          }}
        >
          <Icon name={admin?.adminMode ? "arrow" : "plus"} />
        </button>
      </div>
    </article>
  );
}

/* ───────── Section header ────────────────── */
function SectionHead({ no, label, kicker, count }) {
  // Split label: first word(s) + last word italic
  const parts = label.split(" · ");
  return (
    <div className="section-head">
      <div className="section-no">CAP {no}</div>
      <div className="section-titles">
        <h2 className="section-title">
          {parts.length === 2 ? (
            <>
              {parts[0]} <em>{parts[1]}</em>
            </>
          ) : (
            <>
              {label.split(" ").slice(0, -1).join(" ")}{" "}
              <em>{label.split(" ").slice(-1)[0]}</em>
            </>
          )}
        </h2>
        <p className="section-kicker">{kicker}</p>
      </div>
      <div className="section-count">{String(count).padStart(2, "0")} cortes</div>
    </div>
  );
}

Object.assign(window, { Icon, BullMark, Marbling, UseIcons, PriceLarge, PriceSig, Badge, SigCard, CutCard, SectionHead, formatPrice });
